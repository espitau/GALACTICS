#ifndef GAUSSIANSAMPLING_H
#define GAUSSIANSAMPLING_H

void sample_gaussian_poly(polysmall_t *y1, polysmall_t *y2);

#endif
